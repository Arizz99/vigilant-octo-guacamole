import { NextResponse } from 'next/server';

export async function POST(request) {
    try {
        // Dynamically import the CommonJS module
        const { Buyer } = await import('../../../lib/gamepass.js');
        
        const { cookie } = await request.json();
        
        // Validate input
        if (!cookie) {
            return NextResponse.json(
                { error: 'Missing required parameter: cookie' },
                { status: 400 }
            );
        }

        // Validate cookie format
        if (!cookie.includes('CAEaA')) {
            return NextResponse.json(
                { error: 'Invalid cookie format. Please provide a valid .ROBLOSECURITY cookie.' },
                { status: 400 }
            );
        }

        const buyer = new Buyer(cookie);
        const result = await buyer.autoBuyBasedOnBalance();

        return NextResponse.json(result);

    } catch (error) {
        console.error('API Error:', error);
        
        let errorMessage = error.message;
        if (error.response?.status === 401) {
            errorMessage = 'Invalid or expired cookie. Please refresh your .ROBLOSECURITY cookie.';
        } else if (error.response?.status === 403) {
            errorMessage = 'Insufficient Robux or insufficient permissions.';
        } else if (error.response?.status === 429) {
            errorMessage = 'Rate limited. Try again later.';
        }

        return NextResponse.json(
            { 
                success: false,
                error: errorMessage
            },
            { status: error.response?.status || 500 }
        );
    }
}
